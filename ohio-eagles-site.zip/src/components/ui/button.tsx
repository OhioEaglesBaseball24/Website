import * as React from "react";

type Variant = "default" | "outline";

export function Button({
  className = "",
  variant = "default",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-2 text-sm font-semibold transition-colors";
  const styles =
    variant === "outline"
      ? "border border-white/30 bg-transparent text-white hover:bg-white/10"
      : "bg-white text-black hover:bg-white/90";
  return <button className={`${base} ${styles} ${className}`} {...props} />;
}
