import React, { useEffect, useMemo, useState, type SyntheticEvent } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

// Asset helper: uses /public/images in production
const ASSETS = {
  logo: "/images/ohio-eagles-logo.png",
  champs: "/images/pbr-summer-champs.png",
  monteCarlo: "/images/monte-carlo-night.jpg",
  // Sandbox fallbacks (won't exist on Vercel)
  fallbackLogo: "/mnt/data/OhioEagles_logo (3).png",
  fallbackChamps: "/mnt/data/Screenshot 2026-01-28 at 8.17.48 PM.png",
  fallbackMonteCarlo: "/mnt/data/IMG_9872.jpg",
} as const;

function imgFallback(
  e: SyntheticEvent<HTMLImageElement, Event>,
  fallbackSrc: string
) {
  const img = e.currentTarget;
  // prevent infinite loop
  if (img.dataset.fallbackApplied === "1") return;
  img.dataset.fallbackApplied = "1";
  img.src = fallbackSrc;
}

type RouteKey =
  | "home"
  | "roster"
  | "tournaments"
  | "coaches"
  | "fundraisers"
  | "tryouts"
  | "registration";

const ROUTES: RouteKey[] = [
  "home",
  "roster",
  "tournaments",
  "coaches",
  "fundraisers",
  "tryouts",
  "registration",
];

function parseRouteFromHash(hash: string): RouteKey {
  const key = (hash || "").replace("#", "").trim().toLowerCase();
  return ROUTES.includes(key as RouteKey) ? (key as RouteKey) : "home";
}

function getRouteFromHash(): RouteKey {
  const raw =
    (typeof window !== "undefined" ? window.location.hash : "") || "";
  return parseRouteFromHash(raw);
}

type NavTone = "dark" | "light";

const NavLink = ({
  label,
  to,
  onClick,
  active,
  tone = "dark",
}: {
  label: string;
  to: RouteKey;
  onClick?: () => void;
  active?: boolean;
  tone?: NavTone;
}) => {
  const base = "text-sm font-semibold transition-colors";

  const dark = active
    ? "text-[#FC4C02]"
    : "text-white/85 hover:text-[#FC4C02]";

  const light = active
    ? "text-[#FC4C02]"
    : "text-black/80 hover:text-[#FC4C02]";

  return (
    <a
      href={`#${to}`}
      onClick={onClick}
      className={`${base} ${tone === "light" ? light : dark}`}
    >
      {label}
    </a>
  );
};

function PageShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <main className="px-4 py-10">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-extrabold text-[#FC4C02]">
            {title}
          </h1>
          {subtitle ? (
            <p className="mt-3 text-white/85 max-w-3xl mx-auto">{subtitle}</p>
          ) : null}
        </div>
        {children}
      </div>
    </main>
  );
}

function HomePage() {
  return (
    <div>
      <section className="relative px-4 py-20 text-center overflow-hidden">
        <div aria-hidden="true" className="absolute inset-0">
          <div className="absolute inset-0 bg-black/25" />
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                "radial-gradient(900px 500px at 50% 0%, rgba(255,255,255,0.16), rgba(255,255,255,0) 62%)," +
                "radial-gradient(900px 520px at 50% 120%, rgba(252,76,2,0.14), rgba(255,255,255,0) 65%)",
            }}
          />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto">
          <motion.h1
            style={{ textShadow: "0 6px 24px rgba(0,0,0,0.55)" }}
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-extrabold mb-4"
          >
            Ohio Eagles Travel Baseball
          </motion.h1>
          <p className="text-lg max-w-2xl mx-auto mb-2 text-white/85">
            Elite development • Competitive tournaments • Player-focused training
          </p>
          <p className="text-sm max-w-3xl mx-auto text-white/70">
            Founded in 2025 • Partnered with Prospect Performance Academy (PPA)
          </p>

          <div className="mt-6 flex items-center justify-center gap-6">
            <a
              href="https://x.com/OhioEaglesball"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 font-semibold text-[#FC4C02] hover:underline"
            >
              <span className="text-lg">𝕏</span>
              <span>Follow on X</span>
            </a>
          </div>
        </div>
      </section>

      <section className="px-4 py-12 bg-black/45 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-8 text-[#FC4C02]">
            Program Achievements
          </h2>
          <div className="grid md:grid-cols-3 gap-6 items-stretch">
            <Card className="rounded-2xl bg-black/45 border border-[#FC4C02]/60">
              <CardContent className="p-6 grid gap-2">
                <h3 className="text-2xl font-bold text-[#FC4C02]">
                  🏆 PBR Summer Championship
                </h3>
                <p className="text-white/90">Tournament Champions</p>

                <div className="w-full aspect-[16/9] overflow-hidden rounded-xl border border-[#FC4C02]/60 mt-3">
                  <img
                    src={ASSETS.champs}
                    onError={(e) => imgFallback(e, ASSETS.fallbackChamps)}
                    alt="PBR Summer Championship Team"
                    className="w-full h-full object-cover"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl bg-black/45 border border-[#FC4C02]/60">
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-[#FC4C02]">🥇 3 Top-5 Finishes</h3>
                <p className="text-white/90">Elite Regional Competition</p>
              </CardContent>
            </Card>

            <Card className="rounded-2xl bg-black/45 border border-[#FC4C02]/60">
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-[#FC4C02]">📊 2025 Record</h3>
                <p className="text-3xl font-extrabold text-white mt-2">24–11</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="px-4 py-12">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
          <Card className="rounded-2xl bg-black/45 border border-[#FC4C02]/60">
            <CardContent className="p-6">
              <h2 className="text-3xl font-bold text-[#FC4C02] mb-4">
                About Our Program
              </h2>
              <p className="mb-4 text-white/85">
                Founded in 2025, Ohio Eagles Travel Baseball was built to create a high-level developmental
                environment for committed athletes. In our inaugural season, the program posted a 24–11
                record while competing in PBR and elite regional tournaments.
              </p>
              <p className="text-white/85">
                Ohio Eagles is proudly partnered with <strong>Prospect Performance Academy (PPA)</strong>,
                giving our players access to professional-level training, performance development, and
                structured programming designed for long-term success.
              </p>
            </CardContent>
          </Card>

          <Card className="rounded-2xl bg-black/45 border border-[#FC4C02]/60">
            <CardContent className="p-6">
              <h2 className="text-3xl font-bold text-[#FC4C02] mb-4">Our Mission</h2>
              <p className="text-white/85">
                Our mission is to develop disciplined, confident, and fundamentally sound baseball players
                through elite coaching, advanced training systems, and consistent exposure to high-level
                competition. We emphasize accountability, mental toughness, and a team-first culture that
                prepares athletes for high school, collegiate, and beyond.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="max-w-5xl mx-auto mt-14">
          <h2 className="text-3xl font-bold text-center text-[#FC4C02] mb-6">
            2026 Program Highlights
          </h2>

          <div className="relative aspect-[16/9] rounded-2xl overflow-hidden border border-[#FC4C02]/60 shadow-[0_0_50px_rgba(252,76,2,0.18)]">
            <iframe
              className="w-full h-full"
              src="https://www.youtube-nocookie.com/embed/ZlPDjvs_QYs?rel=0&modestbranding=1&playsinline=1"
              title="Ohio Eagles Program Highlights"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
            <div className="pointer-events-none absolute inset-0 ring-1 ring-[#FC4C02]/40 rounded-2xl" />
          </div>
        </div>
      </section>

      <section className="px-4 pb-12">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
          <Card className="rounded-2xl bg-black/45 backdrop-blur-sm border border-[#FC4C02]/60">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold">16U Program</h3>
              <p className="text-sm text-white/70 mt-2">
                College exposure • Elite tournaments • Advanced development
              </p>
              <a href="#roster" className="inline-block mt-4">
                <Button className="bg-[#FC4C02] text-black rounded-2xl shadow-[0_0_0_3px_rgba(252,76,2,0.35)] hover:shadow-[0_0_0_4px_rgba(252,76,2,0.55)] transition-shadow">
                  View Roster
                </Button>
              </a>
            </CardContent>
          </Card>

          <Card className="rounded-2xl bg-black/45 backdrop-blur-sm border border-[#FC4C02]/60">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold">Tryouts</h3>
              <p className="text-sm text-white/70 mt-2">
                Submit player info through the registration tab to be contacted.
              </p>
              <a href="#registration" className="inline-block mt-4">
                <Button variant="outline" className="rounded-2xl border-white/30 text-white">
                  Player Registration
                </Button>
              </a>
            </CardContent>
          </Card>

          <Card className="rounded-2xl bg-black/45 backdrop-blur-sm border border-[#FC4C02]/60">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold">Team Store</h3>
              <p className="text-sm text-white/70 mt-2">Official Ohio Eagles apparel and gear.</p>
              <a
                href="https://www.team.shop/en-us/node/2016206/share"
                target="_blank"
                rel="noreferrer"
                className="inline-block mt-4"
              >
                <Button className="bg-[#FC4C02] text-black rounded-2xl shadow-[0_0_0_3px_rgba(252,76,2,0.35)] hover:shadow-[0_0_0_4px_rgba(252,76,2,0.55)] transition-shadow">
                  Visit Store
                </Button>
              </a>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="px-4 py-12 bg-black/45 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-6 text-[#FC4C02]">
            Our Sponsors
          </h2>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            {[
              { name: "Ken's Lawnscape" },
              { name: "Legacy Fleet and Auto" },
              { name: "Posh Sound and Lighting" },
              { name: "Sponsor Available" },
            ].map((s, i) => (
              <Card key={i} className="rounded-2xl bg-black/60 border border-[#FC4C02]/60">
                <CardContent className="p-6">
                  <div className="h-20 bg-gray-700/80 rounded" />
                  <p className="mt-2 font-semibold text-[#FC4C02]">{s.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 py-12 text-center">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-4 text-[#FC4C02]">Contact Us</h2>
          <p className="mb-2">📧 Ohioeaglesbaseball@gmail.com</p>
          <p className="mb-2">📞 Kolton Staskey: (330) 413-0962</p>
          <p className="mb-0">📞 Ryan Andrzejczyk: (330) 605-3340</p>
        </div>
      </section>
    </div>
  );
}

type ShowcaseMetric = { label: string; value: string };

type Player = {
  name: string;
  number: number;
  school: string;
  gradYear: string;
  positions: string;
  gpa?: string;
  size: string;
  showcase?: { event?: string; date?: string; metrics: ShowcaseMetric[] };
  videoUrl?: string;
  profileUrl?: string;
};

function RosterPage() {
  const [selected, setSelected] = useState<Player | null>(null);

  const StatPill = ({ m }: { m: ShowcaseMetric }) => (
    <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/85">
      <span className="text-white/60">{m.label}:</span>
      <span className="font-semibold text-white">{m.value}</span>
    </span>
  );

  const PlayerModal = ({ p, onClose }: { p: Player; onClose: () => void }) => (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="relative w-full max-w-3xl"
      >
        <Card className="rounded-3xl bg-black/70 border border-[#FC4C02]/60 shadow-[0_0_0_1px_rgba(252,76,2,0.18),0_25px_90px_rgba(0,0,0,0.65)]">
          <CardContent className="p-7 md:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-2xl md:text-3xl font-extrabold text-[#FC4C02]">
                  #{p.number} {p.name}
                </div>
                <div className="mt-1 text-sm text-white/85">
                  {p.school ? `${p.school} • ` : ""}Class of {p.gradYear}
                </div>
                <div className="mt-1 text-sm text-white/85">
                  {p.positions}{p.gpa ? ` • GPA: ${p.gpa}` : ""}
                </div>
                <div className="mt-1 text-sm text-white/85">{p.size}</div>
              </div>

              <Button
                onClick={onClose}
                variant="outline"
                className="rounded-2xl border-white/25 text-white hover:bg-white/10"
              >
                Close
              </Button>
            </div>

            <div className="mt-7">
              <div className="flex items-center justify-between gap-3">
                <h4 className="text-lg font-extrabold text-white">
                  Showcase Numbers & Stats
                </h4>
                {p.showcase?.event ? (
                  <span className="rounded-full border border-[#FC4C02]/50 bg-black/40 px-3 py-1 text-xs font-bold text-[#FC4C02]">
                    {p.showcase.event}{p.showcase.date ? ` • ${p.showcase.date}` : ""}
                  </span>
                ) : null}
              </div>

              {p.showcase?.metrics?.length ? (
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.showcase.metrics.map((m) => (
                    <StatPill key={`${m.label}-${m.value}`} m={m} />
                  ))}
                </div>
              ) : (
                <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-white/75">
                  Stats will be posted after the next verified showcase/event.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );

  const players: Player[] = [
    { name: "Greysen Mickel", number: 13, school: "Archbishop Hoban High School", gradYear: "2027", positions: "C / CIF", gpa: "4.2", size: "6'1\" • 185 lbs", showcase: { event: "Eagles Showcase", date: "2026", metrics: [{ label: "60", value: "7.10" }, { label: "Exit Velo", value: "92.6 mph" }, { label: "IF Velo", value: "79 mph" }, { label: "Pop Time", value: "1.89" }] } },
    { name: "Leo Milcetich", number: 8, school: "Hudson High School", gradYear: "2028", positions: "MIF / P", gpa: "4.64", size: "5'10\" • 170 lbs", showcase: { event: "Eagles Showcase", date: "2026", metrics: [{ label: "60", value: "7.10" }, { label: "Exit Velo", value: "93.2 mph" }, { label: "IF Velo", value: "78 mph" }] } },
    { name: "Alaunte Massrock", number: 1, school: "Southeast High School", gradYear: "2028", positions: "P / OF", gpa: "3.9", size: "5'11\" • 190 lbs", showcase: { event: "Eagles Showcase", date: "2026", metrics: [{ label: "60", value: "6.86" }, { label: "Exit Velo", value: "93.5 mph" }, { label: "OF Velo", value: "88 mph" }, { label: "Pitching", value: "84 FB • 72 CB • 77 CH" }] } },
  ].slice().sort((a,b)=>a.number-b.number);

  return (
    <>
      {selected ? <PlayerModal p={selected} onClose={() => setSelected(null)} /> : null}
      <PageShell title="Roster" subtitle="16U Ohio Eagles — roster and verified showcase numbers.">
        <div className="grid md:grid-cols-2 gap-4">
          {players.map((p) => (
            <button key={p.name} onClick={() => setSelected(p)} className="text-left">
              <Card className="rounded-2xl bg-black/40 border border-[#FC4C02]/60">
                <CardContent className="p-5">
                  <div className="font-bold text-lg text-[#FC4C02]">#{p.number} {p.name}</div>
                  <div className="text-sm text-white/80 mt-1">{p.school ? `${p.school} • ` : ""}Class of {p.gradYear}</div>
                  <div className="text-sm text-white/80 mt-1">{p.positions}{p.gpa ? ` • GPA: ${p.gpa}` : ""}</div>
                  <div className="mt-3 text-xs text-white/60">Click to view full profile →</div>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      </PageShell>
    </>
  );
}

function TournamentsPage() {
  const events = [
    { date: "June 4th – 10th", title: "College Prospect Showcase (Wood Bat)", location: "", desc: "High-level wood bat exposure event focused on college recruitment and advanced competition.", isPbr: false },
    { date: "June 18th – 21st", title: "PBR Capital City Classic", location: "Columbus, OH", desc: "Premier Prep Baseball event featuring top regional programs competing in the capital city.", isPbr: true },
    { date: "June 24th – 28th", title: "Akron / Kent State Invite", location: "Akron / Kent, OH", desc: "College-campus style event offering strong competition and recruiting visibility.", isPbr: false },
    { date: "July 9th – 12th", title: "PBR Invite-Only", location: "Columbus, OH", desc: "Exclusive invite-only event showcasing elite-level regional and national talent.", isPbr: true },
    { date: "July 16th – 19th", title: "965 BBCOR World Series", location: "North East Ohio", desc: "Competitive World Series event closing out the summer schedule in Northeast Ohio.", isPbr: false },
    { date: "July 23rd – 26th", title: "PBR Great Lakes Underclassmen World Series", location: "Toledo, OH", desc: "Elite underclass showcase tournament featuring top prospects from across the Great Lakes region.", isPbr: true },
  ] as const;

  const infoUrl = (title: string) =>
    `https://www.google.com/search?q=${encodeURIComponent(`${title} 2026`)}`;

  return (
    <PageShell title="Tournaments" subtitle="2026 Ohio Eagles 16U Tournament Schedule">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {events.map((ev) => (
          <a key={ev.title} href={infoUrl(ev.title)} target="_blank" rel="noreferrer" className="group block">
            <Card
              className={
                "relative overflow-hidden rounded-2xl bg-black/45 backdrop-blur-sm border transition-all " +
                (ev.isPbr
                  ? "border-[#FC4C02]/70 shadow-[0_0_0_1px_rgba(252,76,2,0.20),0_0_40px_rgba(252,76,2,0.16)] group-hover:shadow-[0_0_0_1px_rgba(252,76,2,0.28),0_0_56px_rgba(252,76,2,0.24)]"
                  : "border-[#FC4C02]/60 group-hover:shadow-[0_0_24px_rgba(0,0,0,0.45)]")
              }
            >
              <CardContent className="relative p-6">
                <div className="text-sm text-white/70">
                  {ev.date}{ev.location ? ` • ${ev.location}` : ""}
                </div>
                <div className="text-xl font-bold mt-2 text-[#FC4C02]">{ev.title}</div>
                <div className="text-sm text-white/85 mt-2">{ev.desc}</div>
                <div className="mt-5">
                  <Button className="rounded-2xl bg-[#FC4C02] text-black">View Event Info →</Button>
                </div>
              </CardContent>
            </Card>
          </a>
        ))}
      </div>
    </PageShell>
  );
}

function CoachesPage() {
  return (
    <PageShell title="Coaches" subtitle="Player development, recruiting, and next-level preparation.">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="rounded-2xl bg-[#002D72]/85 backdrop-blur border-white/15">
          <CardContent className="p-6">
            <h3 className="text-2xl font-bold text-[#FC4C02]">Kolton Staskey</h3>
            <p className="mt-2 font-semibold text-white">Co-Founder • Infield Coach • Head of Player Recruitment</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl bg-[#002D72]/85 backdrop-blur border-white/15">
          <CardContent className="p-6">
            <h3 className="text-2xl font-bold text-[#FC4C02]">Ryan Andrzejczyk</h3>
            <p className="mt-2 font-semibold text-white">Co-Founder • Pitching Coordinator • Player Development</p>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  );
}

function RegistrationPage() {
  return (
    <PageShell title="Player Registration" subtitle="Submit basic baseball information to be contacted.">
      <Card className="rounded-2xl bg-[#002D72]/90 backdrop-blur border-white/15 max-w-3xl mx-auto">
        <CardContent className="p-8">
          <a
            href="https://docs.google.com/forms/d/e/1FAIpQLSd_Y8POGrPRBFF6rgMq7MSTApJ3bywzS-OSeDD4C9sJHy6JFA/viewform?usp=header"
            target="_blank"
            rel="noreferrer"
            className="text-[#FC4C02] font-semibold hover:underline"
          >
            Open the registration form →
          </a>
        </CardContent>
      </Card>
    </PageShell>
  );
}

function FundraisersPage() {
  return (
    <PageShell title="Fundraisers" subtitle="Annual fundraising events that support Ohio Eagles Baseball.">
      <div className="grid md:grid-cols-2 gap-8">
        <Card className="rounded-2xl bg-[#002D72]/85 backdrop-blur border-white/15">
          <CardContent className="p-6 grid gap-4">
            <h3 className="text-2xl font-bold text-[#FC4C02]">Monte Carlo / Casino Night</h3>
            <div className="w-full aspect-[16/9] overflow-hidden rounded-xl border border-[#FC4C02]/60">
              <img
                src={ASSETS.monteCarlo}
                onError={(e) => imgFallback(e, ASSETS.fallbackMonteCarlo)}
                alt="Monte Carlo Night"
                className="w-full h-full object-cover"
              />
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl bg-[#002D72]/85 backdrop-blur border-white/15">
          <CardContent className="p-6 grid gap-4">
            <h3 className="text-2xl font-bold text-[#FC4C02]">Golf Outing Fundraiser</h3>
            <div className="w-full aspect-[16/9] flex items-center justify-center rounded-xl border border-[#FC4C02]/60 bg-black/60">
              <span className="text-white/70">Golf Outing Image Coming Soon</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  );
}

function TryoutsPage() {
  return (
    <PageShell title="Program Tryouts" subtitle="Tryout and evaluation info.">
      <div className="max-w-4xl mx-auto grid gap-6">
        <Card className="rounded-2xl bg-[#002D72]/85 backdrop-blur border-[#FC4C02]/30">
          <CardContent className="p-6">
            <p className="text-white/90">
              Players interested in Ohio Eagles should complete the Player Registration form.
              Families will be contacted with upcoming tryout dates and details.
            </p>
            <a href="#registration" className="inline-block mt-4">
              <Button className="bg-[#FC4C02] text-black rounded-2xl">Go to Player Registration</Button>
            </a>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  );
}

export default function TravelBaseballWebsite() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [route, setRoute] = useState<RouteKey>("home");

  const nav = useMemo(
    () => [
      { label: "Home", to: "home" as const },
      { label: "Roster", to: "roster" as const },
      { label: "Tournaments", to: "tournaments" as const },
      { label: "Coaches", to: "coaches" as const },
      { label: "Fundraisers", to: "fundraisers" as const },
      { label: "Program Tryouts", to: "tryouts" as const },
      { label: "Player Registration", to: "registration" as const },
    ],
    []
  );

  useEffect(() => {
    const sync = () => setRoute(getRouteFromHash());
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);

  const closeMobile = () => setMobileOpen(false);

  return (
    <div className="min-h-screen text-white relative overflow-hidden">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "radial-gradient(1200px 700px at 50% -10%, rgba(255,255,255,0.28), rgba(255,255,255,0) 60%)," +
              "linear-gradient(180deg, #0b5ed7 0%, #0a4fa6 35%, #083a7c 65%, #062b63 100%)",
          }}
        />
      </div>

      <div className="relative z-10">
        <header className="sticky top-0 z-50 bg-[#0b5ed7]/90 backdrop-blur border-b border-[#FC4C02]/30">
          <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
            <a href="#home" className="flex items-center gap-3" onClick={closeMobile}>
              <img
                src={ASSETS.logo}
                onError={(e) => imgFallback(e, ASSETS.fallbackLogo)}
                alt="Ohio Eagles Logo"
                className="w-10 h-10 object-contain"
              />
              <div className="leading-tight">
                <div className="font-extrabold tracking-tight">Ohio Eagles</div>
                <div className="text-xs text-white/80">Travel Baseball</div>
              </div>
            </a>

            <nav className="hidden md:flex items-center gap-6">
              {nav.map((i) => (
                <NavLink key={i.to} label={i.label} to={i.to} active={route === i.to} />
              ))}
            </nav>

            <div className="md:hidden flex items-center gap-2">
              <button
                onClick={() => setMobileOpen((v) => !v)}
                className="rounded-xl border border-white/20 px-3 py-2 text-sm font-semibold"
                aria-label="Open menu"
              >
                Menu ▾
              </button>
            </div>
          </div>

          {mobileOpen && (
            <div className="md:hidden border-t border-[#FC4C02]/30 bg-white/95 text-black">
              <div className="max-w-6xl mx-auto px-4 py-3 grid gap-3">
                {nav.map((i) => (
                  <NavLink
                    key={i.to}
                    label={i.label}
                    to={i.to}
                    active={route === i.to}
                    onClick={closeMobile}
                    tone="light"
                  />
                ))}
              </div>
            </div>
          )}
        </header>

        {route === "home" && <HomePage />}
        {route === "roster" && <RosterPage />}
        {route === "tournaments" && <TournamentsPage />}
        {route === "coaches" && <CoachesPage />}
        {route === "fundraisers" && <FundraisersPage />}
        {route === "tryouts" && <TryoutsPage />}
        {route === "registration" && <RegistrationPage />}

        <footer className="px-4 py-6 text-center text-sm text-white/70 border-t-4 border-[#FC4C02] bg-[#0b5ed7]/85">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-center gap-3">
            <span>© 2026 Ohio Eagles Travel Baseball. All Rights Reserved.</span>
            <a
              href="https://x.com/OhioEaglesball"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 font-semibold text-[#FC4C02] hover:underline"
            >
              Follow us on X
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}
