# Ohio Eagles Travel Baseball (Vite + React)

## Add your images
Copy images into `public/images/` with these exact names:
- `ohio-eagles-logo.png`
- `pbr-summer-champs.png`
- `monte-carlo-night.jpg`

## Run locally
```bash
npm install
npm run dev
```

## Deploy on Vercel
Build command: `npm run build`  
Output directory: `dist`
